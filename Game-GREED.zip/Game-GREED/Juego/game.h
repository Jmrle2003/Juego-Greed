#ifndef GAME_H
#define GAME_H

#include <string>

const int NUM_DADOS = 5;
const int RONDAS = 3;

void mostrarMenu();
void modoUnJugador(int& maxPuntaje, std::string& nombreMaxPuntaje);
void modoDosJugadores(int& maxPuntaje, std::string& nombreMaxPuntaje);
void mostrarEstadisticas(int maxPuntaje, std::string nombreMaxPuntaje);
void mostrarCreditos();
void jugarRonda(std::string nombre, int& puntajeTotal);
int tirarDados(int dados[], int numDados);
int calcularPuntaje(int dados[], int numDados, int bloqueadores[], int& numDadosDisponibles);
void registrarPuntaje(int puntaje, std::string nombre, int& maxPuntaje, std::string& nombreMaxPuntaje);

#endif // GAME_H
