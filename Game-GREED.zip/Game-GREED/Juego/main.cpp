#include "game.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0))); // Inicializar la semilla para n�meros aleatorios

    int opcion;
    int maxPuntaje = 0;
    string nombreMaxPuntaje;

    do {
        mostrarMenu();
        cin >> opcion;

        switch (opcion) {
            case 1:
                modoUnJugador(maxPuntaje, nombreMaxPuntaje);
                break;
            case 2:
                modoDosJugadores(maxPuntaje, nombreMaxPuntaje);
                break;
            case 3:
                mostrarEstadisticas(maxPuntaje, nombreMaxPuntaje);
                break;
            case 4:
                mostrarCreditos();
                break;
            case 0:
                cout << "Saliendo del juego..." << endl;
                break;
            default:
                cout << "Opcion no valida. Intente de nuevo." << endl;
                break;
        }
    } while (opcion != 0);

    return 0;
}
