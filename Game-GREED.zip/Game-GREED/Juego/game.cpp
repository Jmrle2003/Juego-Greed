#include "game.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

void mostrarMenu() {
    cout << "\nGREED\n";
    cout << "-----------------------\n";
    cout << "1 - MODO UN JUGADOR\n";
    cout << "2 - MODO DOS JUGADORES\n";
    cout << "3 - ESTADISTICAS\n";
    cout << "4 - CREDITOS\n";
    cout << "-----------------------\n";
    cout << "0 - SALIR\n";
    cout << "Seleccione una opcion: ";
}

void modoUnJugador(int& maxPuntaje, string& nombreMaxPuntaje) {
    string nombre;
    cout << "Ingrese su nombre: ";
    cin >> nombre;
    int puntajeTotal = 0;

    for (int i = 0; i < RONDAS; i++) {
        cout << "\nRonda " << i + 1 << endl;
        jugarRonda(nombre, puntajeTotal);
    }

    cout << "\nPuntaje total de " << nombre << ": " << puntajeTotal << endl;
    registrarPuntaje(puntajeTotal, nombre, maxPuntaje, nombreMaxPuntaje);
}

void modoDosJugadores(int& maxPuntaje, string& nombreMaxPuntaje) {
    string nombre1, nombre2;
    cout << "Ingrese el nombre del jugador 1: ";
    cin >> nombre1;
    cout << "Ingrese el nombre del jugador 2: ";
    cin >> nombre2;

    int puntajeTotal1 = 0, puntajeTotal2 = 0;

    for (int i = 0; i < RONDAS; i++) {
        cout << "\nRonda " << i + 1 << " - " << nombre1 << endl;
        jugarRonda(nombre1, puntajeTotal1);

        cout << "\nRonda " << i + 1 << " - " << nombre2 << endl;
        jugarRonda(nombre2, puntajeTotal2);
    }

    cout << "\nPuntaje total de " << nombre1 << ": " << puntajeTotal1 << endl;
    cout << "Puntaje total de " << nombre2 << ": " << puntajeTotal2 << endl;

    registrarPuntaje(puntajeTotal1, nombre1, maxPuntaje, nombreMaxPuntaje);
    registrarPuntaje(puntajeTotal2, nombre2, maxPuntaje, nombreMaxPuntaje);
}

void mostrarEstadisticas(int maxPuntaje, string nombreMaxPuntaje) {
    if (nombreMaxPuntaje != "") {
        cout << "\nEl puntaje mas alto lo tiene " << nombreMaxPuntaje << " con " << maxPuntaje << " puntos." << endl;
    } else {
        cout << "\nAun no se ha registrado ningun puntaje." << endl;
    }
}

void mostrarCreditos() {
    cout << "\nJuego desarrollado por:\n";
    cout << "Equipo: #\n";
    cout << "Integrantes:\n";
    cout << "1. Juan Dalcolmo - 31728\n";
}

void jugarRonda(string nombre, int& puntajeTotal) {
    int dados[NUM_DADOS];
    int bloqueadores[2];
    int puntajeRonda = 0;
    int numDadosDisponibles = NUM_DADOS;
    char seguir;

    // Tirada inicial de los dados bloqueadores
    tirarDados(bloqueadores, 2);
    cout << "Dados bloqueadores: " << bloqueadores[0] << ", " << bloqueadores[1] << endl;

    do {
        int puntajeTirada = tirarDados(dados, numDadosDisponibles);
        cout << "Dados tirados: ";
        for (int i = 0; i < numDadosDisponibles; i++) {
            cout << dados[i] << " ";
        }
        cout << endl;

        // Calcular puntaje de la tirada y reducir la cantidad de dados disponibles
        puntajeTirada = calcularPuntaje(dados, numDadosDisponibles, bloqueadores, numDadosDisponibles);
        puntajeRonda += puntajeTirada;
        cout << "Puntaje de la tirada: " << puntajeTirada << endl;

        // Verificar si todos los dados son iguales y no son iguales a los bloqueadores
        bool todosIguales = true;
        for (int i = 1; i < numDadosDisponibles; i++) {
            if (dados[i] != dados[0]) {
                todosIguales = false;
                break;
            }
        }

        if (todosIguales && numDadosDisponibles > 0 &&
            dados[0] != bloqueadores[0] && dados[0] != bloqueadores[1]) {
            puntajeRonda += puntajeTirada; // Duplicar el puntaje de la tirada
            cout << "�Todos los dados son iguales y no son bloqueadores! Puntaje duplicado." << endl;
            seguir = 's'; // Obligar a tirar nuevamente
        } else {
            // Preguntar si desea continuar
            if (numDadosDisponibles > 0) {
                cout << "Desea seguir tirando dados? (s/n): ";
                cin >> seguir;
            } else {
                seguir = 'n';
            }
        }
    } while (seguir == 's' && numDadosDisponibles > 0);

    cout << "Puntaje de la ronda: " << puntajeRonda << endl;
    puntajeTotal += puntajeRonda;
}


int tirarDados(int dados[], int numDados) {
    for (int i = 0; i < numDados; i++) {
        dados[i] = rand() % 6 + 1; // N�meros entre 1 y 6
    }
    return numDados;
}

int calcularPuntaje(int dados[], int numDados, int bloqueadores[], int& numDadosDisponibles) {
    int puntaje = 0;
    int nuevosDadosDisponibles = 0;

    for (int i = 0; i < numDados; i++) {
        if (dados[i] != bloqueadores[0] && dados[i] != bloqueadores[1]) {
            puntaje += dados[i];
            dados[nuevosDadosDisponibles++] = dados[i];
        }
    }

    numDadosDisponibles = nuevosDadosDisponibles; // Actualizar la cantidad de dados disponibles
    return puntaje;
}

void registrarPuntaje(int puntaje, string nombre, int& maxPuntaje, string& nombreMaxPuntaje) {
    if (puntaje > maxPuntaje) {
        maxPuntaje = puntaje;
        nombreMaxPuntaje = nombre;
        cout << nombre << " ha establecido un nuevo record con " << puntaje << " puntos!" << endl;
    }
}
